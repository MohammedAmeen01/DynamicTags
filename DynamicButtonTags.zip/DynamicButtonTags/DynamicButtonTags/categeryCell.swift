//
//  categeryCell.swift
//  SelectCategery
//
//  Created by ViVID on 3/23/18.
//  Copyright © 2018 ViVID. All rights reserved.
//

import UIKit

class categeryCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
       
               
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
