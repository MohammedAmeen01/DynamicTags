//
//  ViewController.swift
//  DynamicButtonTags
//
//  Created by ViVID on 4/9/18.
//  Copyright © 2018 ViVID. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var count = 0
    var count2 = 0
    var X = 10
    var Y = 10
    var X2 = 10
    var Y2 = 10
    var temp = 1
    var temp2 = 1
    var bool = false
    var bool2 = false
    var phonewidth:CGFloat!
    var categeryView = UIView()
    var selectedcategeryArray = NSMutableArray()
    var selectedbrandArray = NSMutableArray()
    var dummyArray = [Int]()
    var dummyArray2 = NSMutableArray()
    let sectionArray = ["SELECT CATEGARY"]
    
    
    // add your button names in this array
    var categeryArray = ["aaa","bbb","ccc","dddddddddddddd","eeeeee","ffff","gggggggggggggggg","hhh","iiiiiiiiii","jjjjj","aaa","bbb","ccc","ddddddddddddddd","Ameen"]
    
    @IBOutlet weak var selectionTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        phonewidth = self.view.frame.size.width
        
        self.selectionTable.sectionHeaderHeight = UITableViewAutomaticDimension
        self.navigationController?.navigationBar.barTintColor = UIColor.white
        self.navigationItem.title = "Saleslife"
        
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
            let categeryCell = selectionTable.dequeueReusableCell(withIdentifier: "categeryCell", for: indexPath) as! categeryCell
            
            if bool == false{
                
                for i in categeryArray{
                    
                    dummyArray.append(0)
                    
                    let button = UIButton()
                    let size = i.characters.count * 14
                    
                    if count >= 1{
                        var previous = categeryArray[count - 1]
                        let previoussize = previous.characters.count
                        X = X + (previoussize * 14) + 10
                    }
                    button.setTitle(i, for: .normal)
                    button.setTitleColor(UIColor.red, for: .normal)
                    button.layer.cornerRadius = 15
                    button.layer.borderWidth = 1.0
                    button.layer.borderColor = UIColor.red.cgColor
                    button.backgroundColor = UIColor.white
                    button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
                    button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
                    button.tag = count
                    if X >= Int(phonewidth/1.5) || size >= Int(phonewidth/1.5) {
                        X = 10
                        Y = temp * 45 + 10
                        temp = temp + 1
                    }
                    if X >= Int(phonewidth/2) && size >= Int((phonewidth)-(phonewidth/1.6)) {
                        X = 10
                        Y = temp * 45 + 10
                        temp = temp + 1
                    }
                    
                    
                    button.frame = CGRect(x: X, y: Y, width: size , height: 30)
                    
                    categeryCell.addSubview(button)
                    count = count + 1
                }
                bool = true
            }
            
            
            return categeryCell
           }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0
        {
            return CGFloat(45 + Y + 10)
        }
       
        else{
            return 45
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let returnedView = UIView()
       
            returnedView.layer.shadowOffset = CGSize(width: 0, height: 3)
            returnedView.layer.shadowOpacity = 0.3
            returnedView.layer.shadowRadius = 0.4
            returnedView.layer.shadowColor = UIColor.lightGray.cgColor
            
            returnedView.frame = CGRect(x: 0, y: 0, width: self.selectionTable.frame.size.width, height: 50)
            returnedView.backgroundColor = UIColor.white
        
        let label = UILabel()
        label.frame = CGRect(x: 10, y: 0, width: 200, height: 30)
        label.text = self.sectionArray[section]
        
        returnedView.addSubview(label)
        
        return returnedView
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func buttonAction(sender: UIButton!) {
        print("Button tapped")
        
        let selectedBtn:UIButton = sender as UIButton
        
        let check = dummyArray[selectedBtn.tag]
        if check ==  1 {
            selectedBtn.backgroundColor = UIColor.white
            selectedBtn.setTitleColor(UIColor.red, for: .normal)

            dummyArray[selectedBtn.tag] = 0
            print("unseleced")
    
            
        }else{
            selectedBtn.backgroundColor = UIColor.red
            selectedBtn.setTitleColor(UIColor.white, for: .normal)

            dummyArray[selectedBtn.tag] = 1
            print("seleced")

        }
        
    }
    
    
    @IBAction func submitBtn(_ sender: Any) {
        selectedcategeryArray.removeAllObjects()
        let indexArray = dummyArray.indexes(of: 1)
        for i in indexArray{
            selectedcategeryArray.add(categeryArray[i] as Any)
        }
       print(selectedcategeryArray)
    }
    // bar button actions 
    @IBAction func search(_ sender: UIBarButtonItem) {
        
    }
    @IBAction func back(_ sender: UIBarButtonItem) {
        
    }
    
}

extension Array where Element: Equatable {
    func indexes(of element: Element) -> [Int] {
        return self.enumerated().filter({ element == $0.element }).map({ $0.offset })
    }
}

